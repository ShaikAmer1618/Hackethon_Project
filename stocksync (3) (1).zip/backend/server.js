import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';

const app = express();
const PORT = 3000;

// Middleware to understand JSON sent in requests
app.use(express.json());

// 15 Food dishes with live portion counts and food item images
const foodInventory = [
  // Biryanis
  {
    id: 1,
    name: 'Hyderabadi Chicken Dum Biryani',
    category: 'Biryani',
    sku: 'BIR-CHK-001',
    totalStock: 50,
    platformA: 20, // Swiggy
    platformB: 20, // Zomato
    platformC: 10, // Direct
    status: 'synced',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 2,
    name: 'Special Mutton Dum Biryani',
    category: 'Biryani',
    sku: 'BIR-MUT-002',
    totalStock: 35,
    platformA: 15,
    platformB: 12,
    platformC: 8,
    status: 'synced',
    image: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 3,
    name: 'Chicken 65 Biryani',
    category: 'Biryani',
    sku: 'BIR-65-003',
    totalStock: 25,
    platformA: 10,
    platformB: 10,
    platformC: 5,
    status: 'synced',
    image: 'https://images.unsplash.com/photo-1633945274405-b6c8069047b0?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 4,
    name: 'Egg Dum Biryani',
    category: 'Biryani',
    sku: 'BIR-EGG-004',
    totalStock: 5,
    platformA: 2, // Low stock: trigger safety delist
    platformB: 2, // Low stock: trigger safety delist
    platformC: 1, // Critical stock: trigger safety delist
    status: 'low',
    image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=500&auto=format&fit=crop&q=80'
  },

  // Starters
  {
    id: 5,
    name: 'Chicken 65 (Crispy & Spicy)',
    category: 'Starter',
    sku: 'STR-C65-005',
    totalStock: 40,
    platformA: 18,
    platformB: 14,
    platformC: 8,
    status: 'synced',
    image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 6,
    name: 'Chilli Chicken Dry',
    category: 'Starter',
    sku: 'STR-CCD-006',
    totalStock: 30,
    platformA: 12,
    platformB: 12,
    platformC: 6,
    status: 'synced',
    image: 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 7,
    name: 'Chicken Majestic',
    category: 'Starter',
    sku: 'STR-MAJ-007',
    totalStock: 22,
    platformA: 10,
    platformB: 8,
    platformC: 4,
    status: 'synced',
    image: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 8,
    name: 'Tandoori Chicken (Full)',
    category: 'Starter',
    sku: 'STR-TAN-008',
    totalStock: 5,
    platformA: 2, // triggers ghost protection
    platformB: 2, // triggers ghost protection
    platformC: 1, // triggers ghost protection
    status: 'low',
    image: 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 9,
    name: 'Mutton Seekh Kebab',
    category: 'Starter',
    sku: 'STR-MSK-009',
    totalStock: 18,
    platformA: 8,
    platformB: 6,
    platformC: 4,
    status: 'synced',
    image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 10,
    name: 'Mutton Boti Kebab',
    category: 'Starter',
    sku: 'STR-MBK-010',
    totalStock: 4,
    platformA: 2, // triggers ghost protection
    platformB: 1, // triggers ghost protection
    platformC: 1, // triggers ghost protection
    status: 'low',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=500&auto=format&fit=crop&q=80'
  },

  // Chicken Curries
  {
    id: 11,
    name: 'Butter Chicken Masala',
    category: 'Chicken Curry',
    sku: 'CUR-BCM-011',
    totalStock: 28,
    platformA: 12,
    platformB: 10,
    platformC: 6,
    status: 'synced',
    image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 12,
    name: 'Andhra Chicken Curry',
    category: 'Chicken Curry',
    sku: 'CUR-ACC-012',
    totalStock: 32,
    platformA: 14,
    platformB: 12,
    platformC: 6,
    status: 'synced',
    image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 13,
    name: 'Kadai Chicken Gravy',
    category: 'Chicken Curry',
    sku: 'CUR-KCG-013',
    totalStock: 20,
    platformA: 8,
    platformB: 8,
    platformC: 4,
    status: 'synced',
    image: 'https://images.unsplash.com/photo-1546833998-877b37c2e5c6?w=500&auto=format&fit=crop&q=80'
  },

  // Mutton Curries
  {
    id: 14,
    name: 'Mutton Rogan Josh',
    category: 'Mutton Curry',
    sku: 'CUR-MRJ-014',
    totalStock: 15,
    platformA: 6,
    platformB: 6,
    platformC: 3,
    status: 'synced',
    image: 'https://images.unsplash.com/photo-1545247181-516773cae7be?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 15,
    name: 'Hyderabadi Mutton Korma',
    category: 'Mutton Curry',
    sku: 'CUR-HMK-015',
    totalStock: 3,
    platformA: 1, // triggers ghost protection
    platformB: 1, // triggers ghost protection
    platformC: 1, // triggers ghost protection
    status: 'low',
    image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=500&auto=format&fit=crop&q=80'
  }
];

// 1. Health Check Route
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    message: 'StockSync Backend is running',
    timestamp: new Date().toISOString()
  });
});

// 2. Inventory Dishes API Route (GET)
app.get('/api/inventory', (req, res) => {
  res.json({
    success: true,
    totalCount: foodInventory.length,
    dishes: foodInventory,
    timestamp: new Date().toISOString()
  });
});

// 3. Add New Dish API Route (POST)
app.post('/api/inventory', (req, res) => {
  const newDish = req.body;
  if (!newDish || !newDish.name) {
    return res.status(400).json({ success: false, error: 'Dish name is required' });
  }

  const createdDish = {
    id: newDish.id || Date.now(),
    name: newDish.name,
    category: newDish.category || 'Biryani',
    sku: newDish.sku || `DSH-${Math.floor(100 + Math.random() * 900)}`,
    totalStock: Number(newDish.totalStock) || 0,
    platformA: Number(newDish.platformA) || 0,
    platformB: Number(newDish.platformB) || 0,
    platformC: Number(newDish.platformC) || 0,
    status: (Number(newDish.totalStock) || 0) <= 10 ? 'low' : 'synced',
    image: newDish.image || ''
  };

  foodInventory.push(createdDish);
  res.status(201).json({
    success: true,
    message: 'Dish added successfully',
    dish: createdDish
  });
});

// Serve the React frontend through Express
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`StockSync Server running on http://localhost:${PORT}`);
  });
}

startServer();
